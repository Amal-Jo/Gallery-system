package com.parse.libraryapplication;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.DownloadManager;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    public static final String EXTRA_URL = "imageUrl";
    public static final String EXTRA_CREATOR = "creatorName";
    public static final String EXTRA_LIKES = "likeCount";
    public static final String EXTRA_COMMENTS = "commentCount";
    public static final String EXTRA_VIEWS = "viewCount";
    public static final String EXTRA_DOWNLOADS = "downloadCount";
    public static final String EXTRA_TAGS = "tags";
    private RecyclerView myRecyclerview;
    private Adapter myAdapter;
    private ArrayList<items>myArrayList;
    private RequestQueue requestQueue;
    String passedValue,tag;
    int viewCount,downloadCount,commentCount;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Intent intent=getIntent();
        passedValue=intent.getStringExtra("Item_Data");

        myRecyclerview = findViewById(R.id.recycler_view);
        myRecyclerview.setHasFixedSize(true);
        myRecyclerview.setLayoutManager(new LinearLayoutManager(this));

        myArrayList = new ArrayList<>();

        requestQueue = Volley.newRequestQueue(this);
        parseJSON();
    }

    private void parseJSON() {
        String url ="https://pixabay.com/api/?key=15519616-8ac97b7d6e2c163fd520dfab1&q="+passedValue+"&image_type=photo";
        JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET, url, null, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {
                try {
                    JSONArray jsonArray = response.getJSONArray("hits");
                    for (int i=0;i<jsonArray.length();i++){
                        JSONObject hit = jsonArray.getJSONObject(i);

                        String creatorName = hit.getString("user");
                        String imageUrl = hit.getString("webformatURL");
                        int likeCount = hit.getInt("likes");
                        commentCount = hit.getInt("comments");
                        tag = hit.getString("tags");
                        viewCount = hit.getInt("views");
                        downloadCount = hit.getInt("downloads");

                        myArrayList.add(new items(imageUrl,creatorName,likeCount));

                    }
                    myAdapter = new Adapter(MainActivity.this,myArrayList);
                    myRecyclerview.setAdapter(myAdapter);
                    myAdapter.setOnItemClickListener(new Adapter.OnItemClickListener() {
                        @Override
                        public void onItemClick(int position) {
                            Intent descriptionIntent = new Intent(getApplicationContext(),DescriptionActivity.class);
                            items clickedItem = myArrayList.get(position);
                            descriptionIntent.putExtra(EXTRA_URL,clickedItem.getMyImageUrl());
                            descriptionIntent.putExtra(EXTRA_CREATOR,clickedItem.getMyCreator());
                            descriptionIntent.putExtra(EXTRA_LIKES,clickedItem.getMyLikes());
                            descriptionIntent.putExtra(EXTRA_COMMENTS,commentCount);
                            descriptionIntent.putExtra(EXTRA_TAGS,tag);
                            descriptionIntent.putExtra(EXTRA_VIEWS,viewCount);
                            descriptionIntent.putExtra(EXTRA_DOWNLOADS,downloadCount);
                            startActivity(descriptionIntent);

                        }
                    });

                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();
            }
        });
        requestQueue.add(request);
    }
}
