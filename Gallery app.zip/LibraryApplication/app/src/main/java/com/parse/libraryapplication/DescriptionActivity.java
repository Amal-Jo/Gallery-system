package com.parse.libraryapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import static com.parse.libraryapplication.MainActivity.EXTRA_COMMENTS;
import static com.parse.libraryapplication.MainActivity.EXTRA_CREATOR;
import static com.parse.libraryapplication.MainActivity.EXTRA_DOWNLOADS;
import static com.parse.libraryapplication.MainActivity.EXTRA_LIKES;
import static com.parse.libraryapplication.MainActivity.EXTRA_TAGS;
import static com.parse.libraryapplication.MainActivity.EXTRA_URL;
import static com.parse.libraryapplication.MainActivity.EXTRA_VIEWS;

public class DescriptionActivity extends AppCompatActivity {
    MainActivity description = new MainActivity();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_description);

        Intent intent=getIntent();
        String imageUrl = intent.getStringExtra(EXTRA_URL);
        String creatorName = intent.getStringExtra(EXTRA_CREATOR);

        int comments = intent.getIntExtra(EXTRA_COMMENTS,0);
        int views = intent.getIntExtra(EXTRA_VIEWS,0);
        int downloads = intent.getIntExtra(EXTRA_DOWNLOADS,0);
        String tags = intent.getStringExtra(EXTRA_TAGS);


        int likeCount = intent.getIntExtra(EXTRA_LIKES, 0);
        ImageView imageViewDesc = findViewById(R.id.image_view_desc);
        TextView creatorDesc = findViewById(R.id.text_view_creator_desc);
        TextView likesDesc = findViewById(R.id.text_view_like_desc);
        TextView commentDesc = findViewById(R.id.text_view_comments_desc);
        TextView tagsDesc = findViewById(R.id.text_view_tags_desc);
        TextView viewsDesc = findViewById(R.id.text_view_views_desc);
        TextView downloadsDesc = findViewById(R.id.text_view_downloads_desc);

        Picasso.with(this).load(imageUrl).fit().centerInside().into(imageViewDesc);
        creatorDesc.setText("Creator:"+creatorName);
        likesDesc.setText("Likes:"+ likeCount);
        commentDesc.setText("Comments:"+comments);
        tagsDesc.setText("Tags:"+tags);
        viewsDesc.setText("Views:"+views);
        downloadsDesc.setText("Downloads:"+downloads);
    }
}
