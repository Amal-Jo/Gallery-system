package com.parse.libraryapplication;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class Adapter extends RecyclerView.Adapter<Adapter.AdapterViewHolder> {
    private Context myContext;
    private ArrayList<items>myList;
    private OnItemClickListener myListener;

    public interface OnItemClickListener {
        void onItemClick(int position);
    }
    public void setOnItemClickListener(OnItemClickListener listener){
        myListener=listener;
    }
    public Adapter(Context context,ArrayList<items>arrayList){
        this.myContext=context;
        this.myList=arrayList;
    }
    @Override
    public AdapterViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(myContext).inflate(R.layout.items_activity,parent,false);
        return new AdapterViewHolder(view);
    }

    @Override
    public void onBindViewHolder(AdapterViewHolder holder, int position) {
        items currentItem = myList.get(position);
        String imageUrl = currentItem.getMyImageUrl();
        String creatorName = currentItem.getMyCreator();
        int likeCount = currentItem.getMyLikes();

        holder.myCreatorName.setText("Creator:"+creatorName);
        holder.myLikes.setText("Likes:"+likeCount);
        Picasso.with(myContext).load(imageUrl).fit().centerInside().into(holder.myImageView);

    }

    @Override
    public int getItemCount() {
        return myList.size();
    }

    public class AdapterViewHolder extends RecyclerView.ViewHolder {
        public ImageView myImageView;
        public TextView myCreatorName;
        public TextView myLikes;

        public AdapterViewHolder(View itemView) {
            super(itemView);
            myImageView=itemView.findViewById(R.id.image_view);
            myCreatorName=itemView.findViewById(R.id.text_view_creator);
            myLikes=itemView.findViewById(R.id.text_view_likes);
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                   //checking if we have a listener
                   if (myListener!=null){
                       int position = getAdapterPosition();
                       //checking if the position is still valid
                       if (position!=RecyclerView.NO_POSITION){
                           myListener.onItemClick(position);

                       }

                   }
                }
            });
        }
    }
}
