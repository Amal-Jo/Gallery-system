package com.parse.libraryapplication;

public class items {
    private String myImageUrl;
    private String myCreator;
    private int myLikes;

    public items(String myImageUrl, String myCreator, int myLikes){
        this.myImageUrl=myImageUrl;
        this.myCreator=myCreator;
        this.myLikes=myLikes;
    }

    public String getMyImageUrl() {
        return myImageUrl;
    }

    public String getMyCreator() {
        return myCreator;
    }

    public int getMyLikes() {
        return myLikes;
    }
}
